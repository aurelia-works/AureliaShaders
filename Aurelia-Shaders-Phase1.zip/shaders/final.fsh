#version 330 compatibility

#include "/lib/options.glsl"
#include "/lib/tonemap.glsl"
#include "/lib/debug.glsl"

uniform sampler2D colortex0;
uniform float aureliaSmoothedFrameTime;
uniform float aureliaAdaptiveQuality;

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 aureliaSceneColor;

void main() {
    vec4 scene = texture(colortex0, texcoord);
    vec3 color = aureliaGrade(scene.rgb);

#if AURELIA_DEBUG_VIEW == 2
    color = aureliaDebugAdaptive(aureliaSmoothedFrameTime, aureliaAdaptiveQuality);
#elif AURELIA_DEBUG_VIEW == 3
    color = scene.rgb;
#endif

    aureliaSceneColor = vec4(color, scene.a);
}
