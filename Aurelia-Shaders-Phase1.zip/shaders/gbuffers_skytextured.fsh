#version 330 compatibility

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 vertexColor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 aureliaSceneColor;

void main() {
    // Sun/moon textures remain Minecraft-authored; final grading unifies them.
    aureliaSceneColor = texture(gtexture, texcoord) * vertexColor;
}
