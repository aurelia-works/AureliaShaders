#version 330 compatibility

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 vertexColor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 aureliaSceneColor;

void main() {
    // Unlit special geometry (world border, some particles) preserves vanilla
    // intent and avoids inventing normals for a pass that does not provide them.
    aureliaSceneColor = texture(gtexture, texcoord) * vertexColor;
}
