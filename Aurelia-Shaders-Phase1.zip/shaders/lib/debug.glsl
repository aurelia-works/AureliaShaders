vec3 aureliaDebugLighting(vec3 normal, vec2 lightLevel) {
    return vec3(0.5 + 0.5 * normalize(normal).y, lightLevel.y, lightLevel.x);
}

vec3 aureliaDebugAdaptive(float smoothedFrameTime, float quality) {
    // R = pressure (30 ms -> 1), G = quality, B = neutral 50 FPS reference.
    float pressure = smoothstep(0.020, 0.033333, smoothedFrameTime);
    return vec3(pressure, quality, 0.40);
}
