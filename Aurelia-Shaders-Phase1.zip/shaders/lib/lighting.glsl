// Original compact forward lighting. Inputs are world/player-space normal,
// corrected Minecraft lightmap coordinates, and camera-relative view position.

uniform vec3 sunPosition;
uniform vec3 fogColor;
uniform float rainStrength;
uniform mat4 gbufferModelViewInverse;

vec3 aureliaSunDirection() {
    return normalize(mat3(gbufferModelViewInverse) * sunPosition);
}

float aureliaSunHeight() {
    return aureliaSunDirection().y;
}

vec3 aureliaSunColor(float height) {
    float horizon = 1.0 - smoothstep(0.04, 0.34, max(height, 0.0));
    vec3 noon = vec3(1.00, 0.96, 0.86);
    vec3 sunset = vec3(1.00, 0.57, 0.31);
    return mix(noon, sunset, horizon);
}

vec3 aureliaForwardLight(vec3 albedo, vec3 worldNormal, vec2 lightLevel) {
    vec3 lightDir = aureliaSunDirection();
    float sunUp = smoothstep(-0.10, 0.08, lightDir.y);
    float skyLight = clamp(lightLevel.y, 0.0, 1.0);
    float blockLight = clamp(lightLevel.x, 0.0, 1.0);
    float ndl = max(dot(normalize(worldNormal), lightDir), 0.0);

    // Sky light is the broad cool fill; direct light only arrives where the
    // Minecraft lightmap says the sky is visible. Shadow maps arrive in Phase 2.
    vec3 coolAmbient = vec3(0.34, 0.43, 0.62) * (AURELIA_NIGHT_LIFT + 0.46 * skyLight);
    vec3 direct = aureliaSunColor(lightDir.y) * (sunUp * skyLight * ndl * AURELIA_DIRECT_LIGHT);
    vec3 torch = vec3(1.00, 0.58, 0.27) * (blockLight * blockLight * 1.18);
    vec3 weatherDim = vec3(1.0 - 0.38 * rainStrength);

    return albedo * (coolAmbient + direct + torch) * weatherDim;
}

vec3 aureliaApplyFog(vec3 color, vec3 viewPosition) {
    float distanceToCamera = length(viewPosition);
    // An exponential curve keeps nearby blocks crisp and costs no texture read.
    float fog = 1.0 - exp(-distanceToCamera * 0.010 * AURELIA_FOG_DENSITY);
    fog = clamp(fog * (0.55 + 0.45 * rainStrength), 0.0, 0.92);
    return mix(color, fogColor, fog);
}
