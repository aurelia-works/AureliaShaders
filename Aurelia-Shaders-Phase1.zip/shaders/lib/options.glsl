// Every program that uses an option includes this file. Values are compile-time
// Iris options; changing them recompiles the affected program.
#define AURELIA_DIRECT_LIGHT 1.00 // [0.70 0.85 0.90 1.00 1.15] Direct sunlight strength
#define AURELIA_SKY_SATURATION 1.05 // [0.85 0.95 1.05 1.15] Final colour saturation
#define AURELIA_FOG_DENSITY 1.00 // [0.70 0.85 0.90 1.00 1.20] Atmospheric fog density
#define AURELIA_NIGHT_LIFT 0.16 // [0.08 0.12 0.16 0.20 0.22] Playable night ambient floor
#define AURELIA_DEBUG_VIEW 0 // [0 1 2 3] Debug output mode

#define AURELIA_ADAPTIVE // Smooth frame-time controller for future secondary effects

// Keep an explicit test in source so Iris exposes this boolean option.
#ifdef AURELIA_ADAPTIVE
    #define AURELIA_ADAPTIVE_ENABLED 1
#else
    #define AURELIA_ADAPTIVE_ENABLED 0
#endif
