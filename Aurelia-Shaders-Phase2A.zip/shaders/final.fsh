#version 330 compatibility

#include "/lib/options.glsl"
#include "/lib/tonemap.glsl"
#include "/lib/debug.glsl"

uniform sampler2D colortex0;
uniform float aureliaSmoothedFrameTime;
uniform float aureliaAdaptiveQuality;
uniform float aureliaAdaptiveShadowFilterSamples;

#ifdef AURELIA_SHADOWS
uniform sampler2D shadowtex0;
#endif

in vec2 texcoord;

// One linear scene target avoids the Phase 1 linear-to-RGBA8 mismatch and
// preserves dark shadow detail without adding another fullscreen pass. Iris
// reads this directive from a comment; keeping it out of the GLSL source also
// keeps desktop validators portable.
/*
const int colortex0Format = RGB16;
*/

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 aureliaSceneColor;

void main() {
    vec4 scene = texture(colortex0, texcoord);
    vec3 color = aureliaGrade(scene.rgb);

#if AURELIA_DEBUG_VIEW == 2
    color = aureliaDebugAdaptive(aureliaSmoothedFrameTime, aureliaAdaptiveQuality);
#elif AURELIA_DEBUG_VIEW == 3
    color = scene.rgb;
#elif AURELIA_DEBUG_VIEW == 5
    // The forward passes write the scalar factor into scene.rgb. Collapse any
    // non-terrain pixels to luminance as well, then bypass all filmic grading.
    color = vec3(dot(scene.rgb, vec3(0.2126, 0.7152, 0.0722)));
#elif AURELIA_DEBUG_VIEW == 4
    #ifdef AURELIA_SHADOWS
        color = vec3(texture(shadowtex0, texcoord).r);
    #else
        color = vec3(0.0);
    #endif
#elif AURELIA_DEBUG_VIEW == 6
    color = aureliaDebugShadowBudget(aureliaAdaptiveShadowFilterSamples);
#endif

    // All debug modes remain ungraded but still get a display transfer so a
    // scalar is shown as an unambiguous grayscale mask on an sRGB monitor.
    aureliaSceneColor = vec4(aureliaLinearToSrgb(color), scene.a);
}
